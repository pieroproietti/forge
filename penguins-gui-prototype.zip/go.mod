module github.com/pieroproietti/penguins-gui

go 1.25

require fyne.io/fyne/v2 v2.6.3
